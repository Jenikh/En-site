var words_en = Pexeso_words_en;
var words_cz = Pexeso_words_cz;

var cards = [];
for (var i = 0; i < words_en.length; i++) {
    cards.push({ word_en: words_en[i], word_cz: words_cz[i] });
}

function shuffle(a) {
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

function createPexeso() {
    var pexeso = document.createElement("div");
    pexeso.className = "pexeso";
    for (var i = 0; i < cards.length * 2; i++) {
        var card = document.createElement("div");
        card.className = "card";
        card.dataset.id = i;
        pexeso.appendChild(card);
    }
    document.body.appendChild(pexeso);
    pexeso.addEventListener("click", function (event) {
        if (event.target.className == "card") {
            var id = event.target.dataset.id;
            var card = event.target;
            card.innerHTML = cards[id % cards.length].word_en;
            card.className = "card open";
            setTimeout(function () {
                card.innerHTML = "";
                card.className = "card";
            }, 2000);
        }
    });
    shuffle(cards);
}

createPexeso();
