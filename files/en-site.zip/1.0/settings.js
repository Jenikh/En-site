//#region Settings

//#region Words to use
// Pexeso
const preklad_words_en = ["hello", "world", "this", "is", "a", "test"];
const preklad_words_cz = ["ahoj", "svet", "toto", "je", "test"];
//  None

//#endregion Words to use
// Pexeso
const Pexeso_words_cz = ["Ahoj", "Kámen"];
const Pexeso_words_en = ["Hello", "Stone"];


//#endregion Settings